import { DynamoDBClient, GetItemCommand, DeleteItemCommand } from "@aws-sdk/client-dynamodb";
import { S3Client, DeleteObjectCommand }              from "@aws-sdk/client-s3";

const REGION          = "ap-southeast-1";
const TABLE_NAME      = "Product";
const ORIGINAL_BUCKET = "upload-originals-fcj";
const RESIZED_BUCKET  = "resized-image-fcj";

const db = new DynamoDBClient({ region: REGION });
const s3 = new S3Client({ region: REGION });

const CORS_HEADERS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};

export const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }
  const id = event.pathParameters?.id;
  if (!id) {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Missing product id in path" })
    };
  }

  let key;
  try {
    const { Item } = await db.send(new GetItemCommand({
      TableName: TABLE_NAME,
      Key:       { Id: { S: id } },
      ProjectionExpression: "ImageUrl"
    }));
    if (Item?.ImageUrl?.S) {
      const url = Item.ImageUrl.S;
      key = url.split("/").pop();
    }
  } catch (err) {
    console.error("Error fetching product for delete:", err);
  }

  if (key) {
    try {
      await s3.send(new DeleteObjectCommand({
        Bucket: ORIGINAL_BUCKET,
        Key:    key
      }));
      await s3.send(new DeleteObjectCommand({
        Bucket: RESIZED_BUCKET,
        Key:    key
      }));
    } catch (err) {
      console.error("Error deleting images from S3:", err)
    }
  }

  try {
    await db.send(new DeleteItemCommand({
      TableName: TABLE_NAME,
      Key:       { Id: { S: id } }
    }));
  } catch (err) {
    console.error("Error deleting product record:", err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Failed to delete product" })
    };
  }

  return {
    statusCode: 200,
    headers: CORS_HEADERS,
    body: JSON.stringify({
      message: "Product and its images deleted",
      id
    })
  };
};
